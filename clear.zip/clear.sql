-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               8.0.26 - MySQL Community Server - GPL
-- Server OS:                    Win64
-- HeidiSQL Version:             11.3.0.6295
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for clearbnb
CREATE DATABASE IF NOT EXISTS `clearbnb` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `clearbnb`;

-- Dumping structure for table clearbnb.address
CREATE TABLE IF NOT EXISTS `address` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `address` varchar(50) NOT NULL DEFAULT '',
  `city` varchar(50) NOT NULL DEFAULT '',
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `listing_id` int DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table clearbnb.address: ~0 rows (approximately)
/*!40000 ALTER TABLE `address` DISABLE KEYS */;
INSERT INTO `address` (`ID`, `address`, `city`, `date_created`, `listing_id`) VALUES
	(1, 'Fiskaregatan 10', 'Eslöv', '2021-09-17 11:04:11', NULL);
/*!40000 ALTER TABLE `address` ENABLE KEYS */;

-- Dumping structure for table clearbnb.address_revision
CREATE TABLE IF NOT EXISTS `address_revision` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `listing_rev_ID` int NOT NULL,
  `address` varchar(50) NOT NULL DEFAULT '',
  `city` varchar(50) NOT NULL DEFAULT '',
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table clearbnb.address_revision: ~0 rows (approximately)
/*!40000 ALTER TABLE `address_revision` DISABLE KEYS */;
/*!40000 ALTER TABLE `address_revision` ENABLE KEYS */;

-- Dumping structure for table clearbnb.amenities
CREATE TABLE IF NOT EXISTS `amenities` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `listing_ID` int NOT NULL,
  `bathtub` tinyint NOT NULL DEFAULT '0',
  `parkinglot` tinyint NOT NULL DEFAULT '0',
  `stove` tinyint NOT NULL DEFAULT '0',
  `double_bed` tinyint NOT NULL DEFAULT '0',
  `bubble_pool` tinyint NOT NULL DEFAULT '0',
  `cycle` tinyint NOT NULL DEFAULT '0',
  `sauna` tinyint NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`),
  KEY `FK_listing_ID` (`listing_ID`),
  CONSTRAINT `FK_listing_ID` FOREIGN KEY (`listing_ID`) REFERENCES `listing` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table clearbnb.amenities: ~2 rows (approximately)
/*!40000 ALTER TABLE `amenities` DISABLE KEYS */;
INSERT INTO `amenities` (`ID`, `listing_ID`, `bathtub`, `parkinglot`, `stove`, `double_bed`, `bubble_pool`, `cycle`, `sauna`, `date_created`) VALUES
	(1, 12, 1, 1, 1, 1, 0, 0, 1, '2021-09-17 21:04:20'),
	(2, 13, 1, 1, 1, 1, 0, 0, 1, '2021-09-17 21:06:56');
/*!40000 ALTER TABLE `amenities` ENABLE KEYS */;

-- Dumping structure for table clearbnb.amenities_revision
CREATE TABLE IF NOT EXISTS `amenities_revision` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `listing_rev_ID` int NOT NULL DEFAULT '0',
  `bathtub` tinyint NOT NULL DEFAULT '0',
  `parkinglot` tinyint NOT NULL DEFAULT '0',
  `stove` tinyint NOT NULL DEFAULT '0',
  `double_bed` tinyint NOT NULL DEFAULT '0',
  `bubble_pool` tinyint NOT NULL DEFAULT '0',
  `cycle` tinyint NOT NULL DEFAULT '0',
  `sauna` tinyint NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`),
  KEY `FK_list_rev_id` (`listing_rev_ID`),
  CONSTRAINT `FK_list_rev_id` FOREIGN KEY (`listing_rev_ID`) REFERENCES `listing_revision` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table clearbnb.amenities_revision: ~0 rows (approximately)
/*!40000 ALTER TABLE `amenities_revision` DISABLE KEYS */;
/*!40000 ALTER TABLE `amenities_revision` ENABLE KEYS */;

-- Dumping structure for table clearbnb.booking
CREATE TABLE IF NOT EXISTS `booking` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `owner_ID` int NOT NULL,
  `listing_ID` int NOT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`),
  KEY `FK__booking_owner` (`owner_ID`),
  KEY `FK__booking_listing` (`listing_ID`),
  CONSTRAINT `FK__booking_listing` FOREIGN KEY (`listing_ID`) REFERENCES `listing` (`ID`),
  CONSTRAINT `FK__booking_owner` FOREIGN KEY (`owner_ID`) REFERENCES `user` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table clearbnb.booking: ~0 rows (approximately)
/*!40000 ALTER TABLE `booking` DISABLE KEYS */;
/*!40000 ALTER TABLE `booking` ENABLE KEYS */;

-- Dumping structure for table clearbnb.chat_msg
CREATE TABLE IF NOT EXISTS `chat_msg` (
  `chat_msg_id` int NOT NULL AUTO_INCREMENT,
  `current_chat_id` int NOT NULL DEFAULT '0',
  `user_id` int NOT NULL DEFAULT '0',
  `message` varchar(150) NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`chat_msg_id`) USING BTREE,
  KEY `FK_current_chat_ID` (`current_chat_id`),
  KEY `FK_current_user_id` (`user_id`),
  CONSTRAINT `FK_current_chat_ID` FOREIGN KEY (`current_chat_id`) REFERENCES `current_chat` (`current_chat_id`),
  CONSTRAINT `FK_current_user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table clearbnb.chat_msg: ~2 rows (approximately)
/*!40000 ALTER TABLE `chat_msg` DISABLE KEYS */;
INSERT INTO `chat_msg` (`chat_msg_id`, `current_chat_id`, `user_id`, `message`, `date_created`) VALUES
	(1, 1, 1, 'Hej!', '2021-09-18 10:23:49'),
	(2, 1, 2, 'Hej på dig!', '2021-09-18 10:24:29');
/*!40000 ALTER TABLE `chat_msg` ENABLE KEYS */;

-- Dumping structure for table clearbnb.current_chat
CREATE TABLE IF NOT EXISTS `current_chat` (
  `current_chat_id` int NOT NULL AUTO_INCREMENT,
  `closed` tinyint DEFAULT NULL,
  `date_created` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`current_chat_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table clearbnb.current_chat: ~0 rows (approximately)
/*!40000 ALTER TABLE `current_chat` DISABLE KEYS */;
INSERT INTO `current_chat` (`current_chat_id`, `closed`, `date_created`) VALUES
	(1, NULL, '2021-09-17 22:29:39'),
	(2, NULL, '2021-09-18 10:04:03');
/*!40000 ALTER TABLE `current_chat` ENABLE KEYS */;

-- Dumping structure for table clearbnb.image
CREATE TABLE IF NOT EXISTS `image` (
  `image_ID` int NOT NULL AUTO_INCREMENT,
  `listing_ID` int DEFAULT NULL,
  `image_name` varchar(50) NOT NULL DEFAULT '',
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`image_ID`) USING BTREE,
  KEY `FK_img_listing_ID` (`listing_ID`),
  CONSTRAINT `FK_img_listing_ID` FOREIGN KEY (`listing_ID`) REFERENCES `listing` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table clearbnb.image: ~0 rows (approximately)
/*!40000 ALTER TABLE `image` DISABLE KEYS */;
/*!40000 ALTER TABLE `image` ENABLE KEYS */;

-- Dumping structure for table clearbnb.listing
CREATE TABLE IF NOT EXISTS `listing` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `owner_ID` int DEFAULT NULL,
  `description` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `available_start_date` datetime DEFAULT NULL,
  `available_end_date` datetime DEFAULT NULL,
  `price` int DEFAULT NULL,
  `date_created` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`),
  KEY `owner_ID` (`owner_ID`),
  CONSTRAINT `owner_ID` FOREIGN KEY (`owner_ID`) REFERENCES `user` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table clearbnb.listing: ~9 rows (approximately)
/*!40000 ALTER TABLE `listing` DISABLE KEYS */;
INSERT INTO `listing` (`ID`, `owner_ID`, `description`, `available_start_date`, `available_end_date`, `price`, `date_created`) VALUES
	(1, 1, 'Warm House', '2021-01-17 11:03:23', '2021-09-17 11:03:27', 300, '2021-09-17 11:03:39'),
	(2, NULL, '100m to stripclub', '2021-10-10 00:00:00', '2022-10-10 00:00:00', 500, '2021-09-17 12:59:58'),
	(3, NULL, '100m to stripclub', '2021-10-10 00:00:00', '2022-10-10 00:00:00', 500, '2021-09-17 13:01:17'),
	(4, NULL, '100m to stripclub', '2021-10-10 00:00:00', '2022-10-10 00:00:00', 500, '2021-09-17 13:01:39'),
	(5, NULL, '100m to stripclub', '2021-10-10 00:00:00', '2022-10-10 00:00:00', 800, '2021-09-17 13:03:24'),
	(6, NULL, '100m to stripclub', '2021-10-10 00:00:00', '2022-10-10 00:00:00', 8000, '2021-09-17 13:05:06'),
	(10, NULL, 'desc4', '2021-10-01 00:00:00', '2021-11-01 00:00:00', 500, '2021-09-17 13:28:29'),
	(11, NULL, 'desc', '2021-10-01 00:00:00', '2021-11-01 00:00:00', 500, '2021-09-17 14:23:00'),
	(12, NULL, 'desc', '2021-10-01 00:00:00', '2021-11-01 00:00:00', 500, '2021-09-17 21:04:20'),
	(13, NULL, 'desc', '2021-10-01 00:00:00', '2021-11-01 00:00:00', 500, '2021-09-17 21:06:56');
/*!40000 ALTER TABLE `listing` ENABLE KEYS */;

-- Dumping structure for table clearbnb.listing_revision
CREATE TABLE IF NOT EXISTS `listing_revision` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `listing_ID` int NOT NULL DEFAULT '0',
  `owner_ID` int NOT NULL DEFAULT '0',
  `description` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '0',
  `availble_start_date` datetime NOT NULL,
  `available_end_date` datetime NOT NULL,
  `price` smallint NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_listing_rev_list_ID` (`listing_ID`),
  KEY `FK_owner_ID` (`owner_ID`),
  CONSTRAINT `FK_listing_rev_list_ID` FOREIGN KEY (`listing_ID`) REFERENCES `listing` (`ID`),
  CONSTRAINT `FK_owner_ID` FOREIGN KEY (`owner_ID`) REFERENCES `user` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table clearbnb.listing_revision: ~0 rows (approximately)
/*!40000 ALTER TABLE `listing_revision` DISABLE KEYS */;
/*!40000 ALTER TABLE `listing_revision` ENABLE KEYS */;

-- Dumping structure for table clearbnb.rating
CREATE TABLE IF NOT EXISTS `rating` (
  `rating_ID` int NOT NULL AUTO_INCREMENT,
  `sending_user_ID` int NOT NULL DEFAULT '0',
  `receiving_user_ID` int NOT NULL DEFAULT '0',
  `rating` tinyint NOT NULL DEFAULT '0',
  `message` varchar(200) NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`rating_ID`) USING BTREE,
  KEY `FK__rating_sender` (`sending_user_ID`),
  KEY `FK__rating_reciever` (`receiving_user_ID`),
  CONSTRAINT `FK__rating_reciever` FOREIGN KEY (`receiving_user_ID`) REFERENCES `user` (`ID`),
  CONSTRAINT `FK__rating_sender` FOREIGN KEY (`sending_user_ID`) REFERENCES `user` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table clearbnb.rating: ~0 rows (approximately)
/*!40000 ALTER TABLE `rating` DISABLE KEYS */;
/*!40000 ALTER TABLE `rating` ENABLE KEYS */;

-- Dumping structure for table clearbnb.user
CREATE TABLE IF NOT EXISTS `user` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `first_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `sur_name` varchar(20) NOT NULL DEFAULT '',
  `email` varchar(50) NOT NULL DEFAULT '',
  `funds` int NOT NULL DEFAULT '0',
  `password` text NOT NULL,
  `date_created` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table clearbnb.user: ~39 rows (approximately)
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` (`ID`, `first_name`, `sur_name`, `email`, `funds`, `password`, `date_created`) VALUES
	(1, 'Martin', 'Isaksen', 'isaksen@isaksen.se', 10000, 'none', '2021-09-14 20:01:52'),
	(2, 'Marcus', 'Udd', 'udd@udd.com', 10000, 'none', '2021-09-14 20:39:46'),
	(3, 'Yang', 'Li', 'li@li.com', 10000, 'none', '2021-09-14 20:40:14'),
	(4, 'Kundsupport', 'Kundsupport', 'support@support.com', 0, 'none', '2021-09-14 20:41:24'),
	(5, 'Admin', 'Admin', 'admin@admin.com', 0, 'none', '2021-09-14 20:41:49'),
	(6, 'Clear', 'Bnb', 'c@c.com', 0, 'none', '2021-09-14 20:42:24'),
	(7, 'Yang', 'Li', 'odielee@hotmail.com', 10000, 'daitsuki', NULL),
	(8, 'Yang', 'Li', 'odielee@hotmail.com', 10000, 'daitsuki', '2021-09-16 17:12:56'),
	(9, 'Yang', 'Li', 'odielee@hotmail.com', 10000, 'daitsuki', '2000-10-01 00:00:00'),
	(10, 'Yang', 'Li', 'odielee@hotmail.com', 10000, 'daitsuki', NULL),
	(11, 'Yang', 'Li', 'odielee@hotmail.com', 10000, 'daitsuki', NULL),
	(12, 'Yang', 'Li', 'odielee@hotmail.com', 10000, 'daitsuki', '2021-09-17 06:56:44'),
	(13, 'Yang', 'Li', 'odielee@hotmail.com', 10000, 'daitsuki', '2021-09-17 07:13:00'),
	(14, 'Yang', 'Li', 'odielee@hotmail.com', 10000, 'daitsuki', '2021-09-17 07:15:05'),
	(15, 'Yang', 'Li', 'odielee@hotmail.com', 10000, 'daitsuki', '2021-09-17 07:17:26'),
	(16, 'Yang', 'Li', 'odielee@hotmail.com', 10000, 'daitsuki', '2021-09-17 07:24:12'),
	(17, 'Yang', 'Li', 'odielee@hotmail.com', 10000, 'daitsuki', '2021-09-17 07:26:26'),
	(18, 'Yang', 'Li', 'odielee@hotmail.com', 10000, 'daitsuki', '2021-09-17 07:53:02'),
	(19, 'Yang', 'Li', 'odielee@hotmail.com', 10000, 'daitsuki', '2021-09-17 07:58:28'),
	(20, 'Yang', 'Li', 'odielee@hotmail.com', 10000, 'daitsuki', '2021-09-17 08:04:17'),
	(21, 'Yang', 'Li', 'odielee@hotmail.com', 10000, 'daitsuki', '2021-09-17 08:05:13'),
	(22, 'Yang', 'Li', 'odielee@hotmail.com', 10000, 'daitsuki', '2021-09-17 08:12:59'),
	(23, 'Yang', 'Li', 'odielee@hotmail.com', 10000, 'daitsuki', '2021-09-17 08:14:11'),
	(24, 'Yang', 'Li', 'odielee@hotmail.com', 10000, 'daitsuki', '2021-09-17 08:15:05'),
	(25, 'Yang', 'Li', 'odielee@hotmail.com', 10000, 'daitsuki', '2021-09-17 08:18:22'),
	(26, 'Yang', 'Li', 'odielee@hotmail.com', 10000, 'daitsuki', '2021-09-17 08:20:32'),
	(27, 'Yang', 'Li', 'odielee@hotmail.com', 10000, 'daitsuki', '2021-09-17 08:21:59'),
	(28, 'Yang', 'Li', 'odielee@hotmail.com', 10000, 'daitsuki', '2021-09-17 08:22:09'),
	(29, 'Yang', 'Li', 'odielee@hotmail.com', 10000, 'daitsuki', '2021-09-17 08:23:37'),
	(30, 'Yang', 'Li', 'odielee@hotmail.com', 10000, 'daitsuki', '2021-09-17 08:25:17'),
	(31, 'Yang', 'Li', 'odielee@hotmail.com', 10000, 'daitsuki', '2021-09-17 08:26:05'),
	(32, 'Yang', 'Li', 'odielee@hotmail.com', 10000, 'daitsuki', '2021-09-17 08:28:48'),
	(33, 'Yang', 'Li', 'odielee@hotmail.com', 10000, 'daitsuki', '2021-09-17 08:36:50'),
	(34, 'Yang', 'Li', 'odielee@hotmail.com', 10000, 'daitsuki', '2021-09-17 08:38:47'),
	(35, 'Yang', 'Li', 'odielee@hotmail.com', 10000, 'daitsuki', '2021-09-17 08:48:21'),
	(36, 'Yang', 'Li', 'odielee@hotmail.com', 10000, 'daitsuki', '2021-09-17 08:51:06'),
	(37, 'Yang', 'Li', 'odielee@hotmail.com', 10000, 'daitsuki', '2021-09-17 08:55:33'),
	(38, 'Yang', 'Li', 'odielee@hotmail.com', 10000, 'daitsuki', '2021-09-17 08:57:33'),
	(39, 'YangI', 'Li', 'odielee@hotmail.com', 10000, 'daitsuki', '2021-09-17 10:19:55');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
